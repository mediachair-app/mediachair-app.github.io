	<!-- Configuration -->
<link rel="stylesheet" href="http://www.gamehiros.com/auctions/_ebay_hg_mail.css" type="text/css" />
<!-- Begin -->
<link rel="stylesheet" href="http://www.gamehiros.com/auctions/_ebay_hgss.css" type="text/css" />
<div style="padding: 1em; text-align: center; font-family: Arial, sans-serf; font-size: 12pt; background-color: black; color: red; font-weight: bold;" class="gh_hide">
    Unfortunately, eBay couldn't load this auction description correctly this time.<br>
    Please try disabling any internet filters and ad blockers and refresh the page!
</div>
<div class="gh_main">
    <div class="gh_head"></div>
    <table class="gh_t_a">
        <tr>
            <td class="gh_boxart-left">
                <div class="gh_title">
                    <div class="gh_only_mail" style="font-size: 14pt;">Mail in Your Own</div>
                    <div class="gh_only_hg">Pokémon HeartGold Version</div>
                    <div class="gh_only_ss">Pokémon SoulSilver Version</div>
                </div>
                <div class="gh_subtitle"><span>Completely Unlocked</span> and <span>Fully Customizable</span>!</div>
                <div class="gh_title_a">
                    <div class="gh_only_new">
                        <div class="gh_only_hg">
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_01.png"></div>
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_02.png"></div>
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_03.png"></div>
                        </div>
                        <div class="gh_only_ss">
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_01.png"></div>
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_02.png"></div>
                            <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_03.png"></div>
                        </div>
                        <div style="clear: left;"></div>
                    </div>
                    <div class="gh_only_mail gh_desc_msg">
                        <div style="padding-bottom: 8px;">
                            <b>IMPORTANT:</b> This auction is for you to <b>mail in</b> your own copy of Pokémon <span class="gh_only_hg">HeartGold</span><span class="gh_only_ss">SoulSilver</span>!
                            Instructions are located at the bottom of the auction description! ^_^
                        </div>
                        <div>
                            If you don't want to mail us a game for customization,<br>
                            please do check out our other auctions for getting a brand new yet fully customized game!
                        </div>
                    </div>
                </div>
                <div class="gh_title_a">
                    <div class="gh_only_hg">
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_04.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_05.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_06.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_07.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_08.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_09.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_10.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_11.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_hg_12.png"></div>
                    </div>
                    <div class="gh_only_ss">
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_04.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_05.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_06.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_07.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_08.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_09.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_10.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_11.png"></div>
                        <div class="gh_button"><img src="http://www.gamehiros.com/images/auctions/button_ss_12.png"></div>
                    </div>
                    <div style="clear: left;"></div>
                </div>
            </td>
            <td class="gh_boxart gh_only_new">
                <div class="gh_only_hg"><img src="http://www.gamehiros.com/images/auctions/box_hg.jpg"></div>
                <div class="gh_only_ss"><img src="http://www.gamehiros.com/images/auctions/box_ss.jpg"></div>
            </td>
            <td class="gh_boxart gh_only_mail">
                <div class="gh_only_hg"><img src="http://www.gamehiros.com/images/auctions/card_hg.jpg"></div>
                <div class="gh_only_ss"><img src="http://www.gamehiros.com/images/auctions/card_ss.jpg"></div>
            </td>
        </tr>
    </table>
    <table class="gh_t_a">
        <tr>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td colspan="3" class="gh_desc_head_a">New Bark Town: Winds of a New Beginning</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/newbarktown1.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/newbarktown2.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/newbarktown3.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/newbarktown4.png" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 104px;">
                            <div style="padding-bottom: 6px;">
                                The game's main story has been left completely untouched, so you will be starting
                                your adventure from your very own room in <b>New Bark Town</b>!
                            </div>
                            <div style="padding-bottom: 6px;">
                                This means you can challenge all of the Legendary Pokémon and Gym Leaders yourself!
                            </div>
                            <div>
                                <b>Experience the full game with no limits!</b>
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td colspan="3" class="gh_desc_head_a">*EXCLUSIVE* -- Full Control Over Your Game</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics" style="text-align: center;">
                                <a href="http://www.gamehiros.com/" target="_blank"><img src="http://www.gamehiros.com/images/screenshots/hgss/more/customizer.jpg" style="border: 1px solid black;" /></a>
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 104px;">
                            <div style="padding-bottom: 6px;">
                                <b>Only with us</b> you have <b>full control</b> over your game!
                                That means you can customize it to your liking in any and every single detail!
                            </div>
                            <div>
                                We developed a straightforward, web-based tool where you can not only customize
                                the Trainer but also every single Pokémon!
                                After (or even before) winning this auction, you can submit your prefered configuration right over here:
                            </div>
                            <div style="padding-left: 15px;">
                                • <a href="http://www.gamehiros.com/" target="_blank"><b>Pokémon DS Customizer</b> for Pokémon <span class="gh_only_hg">HeartGold</span><span class="gh_only_ss">SoulSilver</span></a>
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="gh_t_a">
        <tr>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td class="gh_desc_head_b">Your 540 Pokémon in 18 PC Boxes</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/box.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/kevin.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/sabrina.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/shiny.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 84px;">
                            <div>
                                In the PC Box System you can access at any Pokémon Center, you will find all
                                493 different Pokémon in all 540 Slots! Start off your adventure with
                                any Pokémon you like, even Shiny and at Lv. 100!
                                Only with us you will you have full control!
                                You can <a href="http://www.gamehiros.com/" target="_blank"><b>fully customize</b></a>
                                every single possible aspect of every single Pokémon.
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td class="gh_desc_head_b">The Most Complete Pokémon Collection</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/diploma.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/pokedex1.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/pokedex2.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/pokedex3.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 84px;">
                            <div>
                                <span class="gh_only_new">By default, your game comes with a fully completed Pokédex!</span>
                                <span class="gh_only_mail">By default, your game returns to you with a fully completed Pokédex!</span>
                                That means both the Johto and the National Pokédex will have all the
                                international entries for every single Pokémon registered in every of the six languages:
                                English, French, Spanish, German, Italian, and Japanese!
                                Forme and gender differences are in there as well!
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="gh_t_a">
        <tr>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td colspan="3" class="gh_desc_head_a">Event Pokémon Galore!</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/pichu-event.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/arceus-event.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/celebi-event.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/gifts2.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/gifts.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/event-pokemon.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 152px;">
                            <div style="padding-bottom: 6px;">
                                We collected <b>over 70+ Event Pokémon</b> from all around the world.
                                Our Customizer lets you freely put any of our Event Pokémon into any Box slot!
                                Because all our Event Pokémon are legit and tested, they will also of course
                                unlock various Secret Events within the game for you to experience:
                            </div>
                            <div>
                                Meet the cute <b>Spiky-Eared Pichu</b> in Ilex Forest!
                                Be a witness of your <b>Arceus</b>' power when it creates a
                                Dialga, Palkia, or Giratina, just for you at the Shinjoh Ruins!
                                And travel through time with your <b>Celebi</b> -- challenge Giovanni,
                                the Boss of Team Rocket, for an intense Pokémon battle!
                                And don't forget the Pokémon Ranger <b>Manaphy Egg</b>!
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td colspan="3" class="gh_desc_head_a">Challenge Every Legendary Pokémon in the Game</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/gifts3.gif" style="border: 1px solid black;" />
                                <img class="gh_only_ss" src="http://www.gamehiros.com/images/screenshots/hgss/more/lugia.gif" style="border: 1px solid black;" />
                                <img class="gh_only_hg" src="http://www.gamehiros.com/images/screenshots/hgss/more/ho-oh.gif" style="border: 1px solid black;" />
                                <img class="gh_only_ss" src="http://www.gamehiros.com/images/screenshots/hgss/more/ho-oh.gif" style="border: 1px solid black;" />
                                <img class="gh_only_hg" src="http://www.gamehiros.com/images/screenshots/hgss/more/lugia.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/raikou-entei-suicune.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/articuno.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/zapdos.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/moltres.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/mewtwo.gif" style="border: 1px solid black;" />
                                <img class="gh_only_hg" src="http://www.gamehiros.com/images/screenshots/hgss/more/kyogre.gif" style="border: 1px solid black;" />
                                <img class="gh_only_ss" src="http://www.gamehiros.com/images/screenshots/hgss/more/groudon.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/more/rayquaza.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 152px;">
                            <div style="padding-bottom: 6px;">
                                <span class="gh_only_new">With your new game you're going to have access to any of the many Legendary Pokémon:</span>
                                <span class="gh_only_mail">When your game is returned to you, you're going to have access to any of the many Legendary Pokémon:</span>
                                <b>Lugia</b>, <b>Ho-oh</b>,
                                <b>Raikou</b>, <b>Entei</b>, <b>Suicune</b>,
                                <b>Latias</b>, <b>Latios</b>,
                                <b>Articuno</b>, <b>Zapdos</b>, <b>Moltres</b>,
                                <b>Mewtwo</b>,
                                <span class="gh_only_hg"><b>Kyogre</b>, </span><span class="gh_only_ss"><b>Groudon</b>, </span> and <b>Rayquaza</b>!
                            </div>
                            <div style="padding-bottom: 16px;">
                                That's right! You even have access to both Latias <b>and</b> Latios,
                                because you will obtain the mysterious <b>Enigma Crystal</b>,
                                an item that attracts these dragons. The green delivery man
                                waits for you in any Poké Mart.
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="gh_t_a">
        <tr>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td class="gh_desc_head_b">All the Items, Accessories, Apricorns, and Seals</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/items.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/accessories.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/apricorns.png" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/seals.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 136px;">
                            <div style="padding-bottom: 6px;">
                                Your game is preloaded with every possible item at the maximum quantity -- minus one, so you can still pick up the ones from the game story!
                                Look forward to all the <b>Adventure Items</b>, <b>Medicine</b>, <b>Poké Balls</b>, <b>TMs &amp; HMs</b>, <b>Berries</b>, <b>Mail</b>, and <b>Battle Items</b>!
                                Of course, all the <b>Accessories</b>, <b>Backdrops</b>, <b>Apricorns</b>, and <b>Ball Capsule Seals</b> are included as well.
                            </div>
                            <div>
                                However, if you wouldn't like all the items from the beginning, you can
                                of course choose to exclude them (just like you can do with anything else listed here)
                                while configuring your game with our Customizer!
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
            <td class="gh_desc_a">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td class="gh_desc_head_b">All Secret Box Wallpapers and Pokéwalker Routes</td></tr>
                    <tr><td class="gh_desc_body">
                        <div class="gh_screenshotdiv">
                            <div class="gh_screenshotpics">
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/wallpapers.gif" style="border: 1px solid black;" />
                                <img src="http://www.gamehiros.com/images/screenshots/hgss/routemaps-menu.gif" style="border: 1px solid black;" />
                            </div>
                        </div>
                        <div class="gh_belowscreenshots" style="height: 136px;">
                            <div style="padding-bottom: 6px;">
                                Decorate your PC Boxes with those supercool, well-designed Event Wallpapers!
                            </div>
                            <div>
                                All 27 Pokéwalker Route Maps can be unlocked as well if you choose to!
                                This is just in case you do not have access to the Nintendo Wi-Fi Connection at home. ^_^
                            </div>
                        </div>
                    </td></tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="gh_t_a">
        <tr>
            <td class="gh_desc_a" style="width: 1000px;">
                <table class="gh_desc_a_a" cellspacing="1" border="0">
                    <tr><td class="gh_desc_head_a">Information and Instructions</td></tr>
                    <tr><td class="gh_desc_body">
                        <table style="width: 100%; font-size: 1em;">
                            <tr class="gh_only_mail">
                                <td colspan="2" style="width: 100%;">
                                    <div class="gh_info_head">Mailing Instructions</div>
                                    <div style="text-align: center;">
                                        <div style="padding-bottom: 4px;">
                                            You will <b>not</b> be buying the actual game in this auction.<br>
                                            Here is where you can get the listed customizations uploaded onto
                                            your own existing game card!
                                        </div>
                                        <div>
                                            Please place your game in a bubble-protected envelope, along with a note detailing your eBay name!<br>
                                            Our address is:
                                        </div>
                                        <div style="padding-top: 4px;">
                                            Dan & Drew<br>
                                            7820 McLaughlin Rd S Apt 507<br>
                                            Brampton ON L6Y 4W3<br>
                                            Canada<br>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 50%;">
                                    <div class="gh_info_head">Terms and Conditions</div>
                                    <ul>
                                        <li><b>Free Shipping</b> and <b>Free Insurance</b> worldwide!</li>
                                        <li class="gh_only_new">This game is an original and genuine Nintendo DS game we purchased from a local retail store.</li>
                                        <li class="gh_only_mail">We won't break your game and handle it with care.</li>
                                        <li class="gh_only_new">The game will be mailed out to you from Canada <b>within 12 hours of your payment</b> and you will receive a free Canada Post shipping notification in your e-mail!</li>
                                        <li class="gh_only_mail">Your game will be returned to you within <b>12 hours</b> of receiving it in the mail and you will receive a free Canada Post shipping notification in your e-mail!</li>
                                        <li>Different shipping services (FedEx or Purolator) are possible, but please contact us before bidding!</li>
                                        <li class="gh_only_new">We offer a <b>30 Days Exchange Guarantee</b>! There hasn't been a single problem with any games we shipped in the past four years, but if you do think there's something wrong, we'll ask you to send it back, and the day we receive it, we'll ship a brand new game to you!</li>
                                        <li class="gh_only_mail">We offer a <b>30 Days Exchange Guarantee</b>! There hasn't been a single problem with any games we customized in the past four years, but if you do think there's something wrong, we'll ask you to send it back, and the day we receive it, we'll fix it and return it to ya!</li>
                                    </ul>
                                </td>
                                <td style="width: 50%;">
                                    <div class="gh_info_head">Instructions for the Customizer</div>
                                    <ul>
                                        <li>Simply visit our exclusive <a href="http://www.gamehiros.com/" target="_blank"><b>Pokémon DS Customizer</b></a> to customize your very own Pokémon <span class="gh_only_hg">HeartGold</span><span class="gh_only_ss">SoulSilver</span> game! You can do this either before or after winning the auction!</li>
                                        <li>Once we receive both your customizations and your payment, your customized Pokémon <span class="gh_only_hg">HeartGold</span><span class="gh_only_ss">SoulSilver</span> game will be mailed out to you within just 12 hours!</li>
                                        <li class="gh_only_new"><b>Please Note:</b> If we do not receive a customization from you within 12 hours of your payment, we'll automatically send you a package of Level 100 Shiny Pokémon with a male Trainer named after your last name, the default extras, and a random Trainer ID number.</li>
                                        <li class="gh_only_mail"><b>Please Note:</b> If we do not receive a customization from you by the time your game arrives in the mail, we'll automatically send your game back with Level 100 Shiny Pokémon with a male Trainer named after your last name, the default extras, and a random Trainer ID number.</li>
                                        <li>If you do need more time to customize your game, just let us know by sending a message or an e-mail to us, and we'll gladly wait as long as you need!</li>
                                        <li>When you receive the game do not delete the existing savegame. Do that only if you no longer want these extras. You must "Continue" in order to enjoy these extras.</li>
                                    </ul>
                                </td>
                            </tr>
                        </table>
                        <div style="text-align: center;">
                            And of course, if you have any question, please don't hesitate and contact us
                            <br>
                            by sending an eBay message or mailing us at <b>&#115;&#117;&#112;&#112;&#111;&#114;&#116;&#64;&#103;&#97;&#109;&#101;&#104;&#105;&#114;&#111;&#115;.&#99;&#111;&#109;</b>!
                            <br>
                            Thanks! ^_^
                        </div>
                        <div class="gh_namechange">
                            We recently changed our eBay name from <i>dvd05</i> to <i>GameHiros</i> to start off with a brand new Pokémon DS Customizer at <a href="http://www.gamehiros.com/" target="_blank">http://www.gamehiros.com/</a>.
                        </div>
                    </td></tr>
                </table>
            </td>
        </tr>
    </table>
    <div class="gh_bottomline">
        <b>Redistribution or reselling of our preload savegame data is not permitted.</b>
        <br>
        Pokémon, Pokémon character names, and Nintendo DS, are trademarks of Nintendo.
        We are in no way affiliated with Nintendo.
    </div>
</div>
<!-- End -->